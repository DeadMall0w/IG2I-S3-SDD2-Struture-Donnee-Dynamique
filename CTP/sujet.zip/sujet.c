
#include<stdio.h>
#include <stdlib.h>
#include <time.h>

#define LIGNES 5
#define COLONNES 15

typedef struct{ //4 couleurs et 8 cartes de chaque couleur = 32 cartes

    int valeur; //entre 7 et 14   14=AS  13=ROI  12=DAME  11=VALET
    int couleur; //entre 1 et 4

} T_Carte;


typedef struct maille
{
    T_Carte carte;
    struct maille *suiv;
}T_Maille;




T_Maille* lireTasCartes(char *ch)
{
    T_Maille *liste=NULL;
    FILE *fic=NULL;
    T_Carte  uneCarte;



    fic=fopen(ch,"r");

    do
    {
        fread(&uneCarte,sizeof(T_Carte),1,fic);
        if (!feof(fic))
        {printf("\n %d--%d",uneCarte.valeur,uneCarte.couleur);

                //ici inserez chaque cartes lue EN FIN DE votre liste chainee (avec votre fonction insererEnFin)
            // IMPORTANT !! avec insererEnFin et rien d'autre

        }
    }while(!feof(fic));
    fclose(fic);
    return liste;
}



int tailleListe(T_Maille *l)
{
    int c=0;
    while(l!=NULL) {c++;l=l->suiv;}
    return c;
}

void reussite(T_Maille *l)
{

    //à ecrire
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{
    T_Maille *L=NULL;

     srand( time( NULL ) );


     L=lireTasCartes("tas1.32"); //vous testerez les 10 fichiers de données disponibles (tas1 à tas10)
     printf("\nTAILLE AVANT=%d", tailleListe(L));
     //reussite(L);
     printf("\n\nTAILLE APRES=%d", tailleListe(L));


    }
